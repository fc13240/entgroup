package com.entgroup.adms.listener;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.entgroup.adms.model.system.AdDisplayCount;
import com.entgroup.adms.service.AdDisplayCountService;
import com.entgroup.adms.util.DateUtils;

/**
 * 
 * @author guofei
 * @ClassName: GetDisplayCount.java
 * @Description: 统计前一天的曝光量 添加到曝光表中
 * @date 2017-4-18
 */
//@Component              task
public class GetDisplayCount {

	private Logger log = LoggerFactory.getLogger(GetDisplayCount.class);
	@Resource
	private AdDisplayCountService adDisplayCountService;
//	@Scheduled(cron = "* * 0 * * ?")         task
	public void executeGetDisplayCount() {
		log.info("executeGetDisplayCount..............");
		// 获取前一天的日期
		String beforeDay = DateUtils.getBeforeDay((long) 1);
		Date parseDate = DateUtils.parseDate(beforeDay);
		// 获取当前日期
		String nowDay = DateUtils.getBeforeDay((long) 0);
		// 从记录`sys_ad_display_record` 中获取对应广告的用户量和曝光量，相同设备为同一个用户 （********）
		List<AdDisplayCount> displayCountList = adDisplayCountService
				.selectDisplayCount(beforeDay, nowDay);
		for (AdDisplayCount adDisplayCount : displayCountList) {
			adDisplayCount.setDayTime(parseDate);
		}
		try {
			// 批量添加统计表
			boolean insertBatch = adDisplayCountService
					.insertBatch(displayCountList);
			if (insertBatch) {
				log.debug("添加数据统计成功");
			}
		} catch (Exception e) {
			log.error("添加数据统计失败");
		}
		if (log.isDebugEnabled()) {
			log.info("executeGetDisplayCount......");
			log.debug("executeGetDisplayCount...displayCountList.size:{}", displayCountList.size());
		}
	}
	
}
