package com.entgroup.adms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author MaxNull
 * @since 2017-05-05
 */
@Controller
@RequestMapping("/platformPrice")
public class PlatformPriceController {
	
}
