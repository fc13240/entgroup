package com.entgroup.adms.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.entgroup.adms.aop.SystemControllerLog;
import com.entgroup.adms.dto.AdDTO;
import com.entgroup.adms.dto.AdOrderListDTO;
import com.entgroup.adms.dto.OrderAdListDTO;
import com.entgroup.adms.model.JsonResult;
import com.entgroup.adms.model.system.*;
import com.entgroup.adms.util.DateUtils;
import com.entgroup.adms.util.PageInfo;
import com.entgroup.adms.util.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 
 * @author guofei 2017-3-23
 */
@Controller
@RequestMapping("/order")
public class OrderController extends BaseController {
	/**
	 * 系统模块名
	 */
	private static final String SYSTEM_MODULE = "管理员订单页面";

	/**
	 * 
	 * @Title: updateOrderSlot  
	 * @Description: 刷新广告位数量  
	 * @param model
	 * @return
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	// FIXME 修改广告位数量 之后需要删除
	@RequestMapping(value = "/updateOrderSlot", method = RequestMethod.GET, produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public JsonResult updateOrderSlot(Model model) {
		log.info("updateOrderSlot...........");
		// 获取所有的订单
		Wrapper<AdOrder> adOrderwrapper = new EntityWrapper<AdOrder>();
		adOrderwrapper.eq("status", 1);
		List<AdOrder> selectObjs = adOrderService.selectList(adOrderwrapper);
		for (AdOrder adOrder : selectObjs) {
			// 根据订单获取对应的订单id
			String OrderId = adOrder.getId();
			// 根据订单id获取广告位数量
			int countForOrderSlot = orderAdService.selectCountForSlot(OrderId);
			adOrder.setSlotCount((long) countForOrderSlot);
		}
		boolean updateBatchById = adOrderService.updateBatchById(selectObjs);
		if (updateBatchById) {
			jr = renderSuccess("更新广告位成功");
		} else {
			jr = renderError("更新广告位失败");
		}

		if (log.isDebugEnabled()) {
			log.info("updateOrderSlot......");
			log.debug("updateOrderSlot...selectObjs:{}", selectObjs);
			log.debug("updateOrderSlot...updateBatchById:{}", updateBatchById);
		}

		return jr;
	}

	/**
	 * 
	 * @Title: showAdByCompanyId  
	 * @Description: 根据公司id获取所有的广告及广告样式  
	 * @param companyId
	 * @param model
	 * @return
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	@SystemControllerLog(moduleName = { SYSTEM_MODULE }, description = "添加时获取广告样式")
	@RequestMapping(value = "/selectAdStyle", method = RequestMethod.GET, produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String showAdByCompanyId(@RequestParam(required = false) String companyId, Model model) {
		log.info("selectAdStyle");
		// 根据公司id获取对应的广告以及广告的样式名
		List<AdDTO> adListByCompany = adService.selectAdListByCompany(companyId);
		for (AdDTO adDTO : adListByCompany) {
			Date created = adDTO.getNewDate();
			String date = DateUtils.formatDate(created);
			adDTO.setDate(date);
		}
		if (log.isDebugEnabled()) {
			log.info("selectAdStyle......");
			log.debug("selectAdStyle...companyId:{}", companyId);
			log.debug("selectAdStyle...result adListByCompany size:{}", adListByCompany.size());
		}
		model.addAttribute("adListByCompany", adListByCompany);
		return JSON.toJSONString(model, SerializerFeature.WriteMapNullValue);
	}

	/**
	 * 
	 * @Title: saveAdOrder  
	 * @Description: 添加订单  
	 * @param adOrder
	 * @param adIds
	 * @param model
	 * @return
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	// @RequiresPermissions(value = {
	// AuthorityConstants.Order.PERMISSION_ORDERLIST_ADD }, logical =
	// Logical.OR)
	@ResponseBody
	@RequestMapping("/saveAdOrder")
	@SystemControllerLog(moduleName = { SYSTEM_MODULE }, description = "订单更新")
	public JsonResult saveAdOrder(@ModelAttribute("adOrder") AdOrder adOrder,
			@RequestParam(required = false) String adIds, Model model) {
		log.info("saveAdOrder...........");
		User shiroUser = getShiroUser();
		Long userId = shiroUser.getId();
		// 生成订单号
		StringBuffer buffer = new StringBuffer();
		Long companyId = adOrder.getCompanyId();
		String format = DateUtils.getDateTimeStr();
		String remark = null;
		try {
			remark = adOrder.getRemark();
			String temp = new String(remark.getBytes("ISO-8859-1"), "utf-8");
			remark = URLDecoder.decode(temp, "utf-8");
		} catch (UnsupportedEncodingException e) {
		}
		adOrder.setRemark(remark);
		StringBuffer orderId = buffer.append(companyId).append(userId).append(format);

		adOrder.setId(orderId.toString());

		String[] adIdByte = null;
		List<String> adIdList = new ArrayList<String>();
		List<OrderAd> orderAdList = new ArrayList<>();
		if (adOrder.getAdIds() != null && adOrder.getAdIds() != "") {
			// 获取复选框中的 adid
			adIdByte = adOrder.getAdIds().split(",");
			orderAdList = new ArrayList<>();
			for (String adId : adIdByte) {
				OrderAd orderAd = new OrderAd();
				orderAd.setOrderId(orderId.toString());
				long decode = Long.parseLong(adId);
				orderAd.setAdId(decode);
				orderAd.setDeleted(0);
				orderAdList.add(orderAd);
				adIdList.add(adId);
			}
		}

		adOrder.setSlotCount(0L);
		adOrder.setStatus(1);
		adOrder.setCosumeMoney(0);
		try {
			// 批量添加orderAd表
			if (orderAdList != null) {
				orderAdService.insertBatch(orderAdList);
			}
			// 批量修改广告已关联订单
			if (adIdList != null) {
				List<Ad> adList = adService.selectBatchIds(adIdList);
				for (Ad ad : adList) {
					ad.setOrderOnline(1);
				}
				adService.updateBatchById(adList);
				adOrder.setAdCount(adIdList.size());
			}
			// 添加订单信息
			adOrderService.insertAdOrder(adOrder);
			// 添加通知信息
			noticeService.addAdOrderNotice(adOrder);
			jr = renderSuccess("添加订单成功");
		} catch (Exception e) {
			e.printStackTrace();
			jr = renderError("添加订单失败");
		}

		if (log.isDebugEnabled()) {
			log.info("saveAdOrder......");
			log.debug("saveAdOrder...userId:{}", userId);
			log.debug("saveAdOrder...AdOrder:{}", adOrder.toString());
			log.debug("saveAdOrder...orderAdList.size:{}", orderAdList.size());
		}

		return jr;
	}

/**
 * 
 * @Title: adOrderAdDetail  
 * @Description: 订单广告详情  
 * @param adId
 * @param status
 * @param model
 * @return
 * @throws Exception
 * @author guofei 
 * @date 2017年5月5日
 */
	@SystemControllerLog(moduleName = { SYSTEM_MODULE }, description = "广告位详情")
	@RequestMapping(value = "/adOrderAdDetail", method = RequestMethod.GET, produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String adOrderAdDetail(@RequestParam(required = false) Integer adId,
			@RequestParam(required = false) String status,
			Model model) throws Exception {
		log.info("adOrderAdDetail....");
		boolean statusHas = StringUtils.isNotNull(status);
		List<OrderAdListDTO> allSlotList=null;
		if(statusHas){
			if(status.equals("1")){
				allSlotList = orderAdService.selectAllSlotListByAdId(adId);
			}
			if(status.equals("2")){
				allSlotList=null;
			}
		}
		
		if(allSlotList!=null){
			for (OrderAdListDTO orderAdListDTO : allSlotList) {
				Integer videoPosition = orderAdListDTO.getVideoPosition();
				String second2Time = second2Time(videoPosition);
				orderAdListDTO.setSlotTime(second2Time);
			}
		}
		if (log.isDebugEnabled()) {
			log.info("adOrderAdDetail......");
			log.debug("adOrderAdDetail...adId:{}", adId);
			if(allSlotList!=null){
				log.debug("adOrderAdDetail...result allSlotList size:{}", allSlotList.size());
			}
		}
		model.addAttribute("allSlotList", allSlotList);
		return JSON.toJSONString(model, SerializerFeature.WriteMapNullValue);
	}

	/**
	 * 
	 * @method: adOrderList
	 * @description: 订单列表
	 * @param pageNum
	 * @param pageSize
	 * @param companyId
	 * @param model
	 * @return
	 * @throws Exception
	 * @author guofei
	 * @date 2017-4-18
	 */
	// @RequiresPermissions(value = {
	// AuthorityConstants.Order.PERMISSION_ORDERLIST_LIST }, logical =
	// Logical.OR)
	@RequestMapping("/adOrderList")
	@SystemControllerLog(moduleName = { SYSTEM_MODULE }, description = "管理员订单页列表")
	public String adOrderList(@RequestParam(required = false, defaultValue = PAGE_NUM) Integer pageNum,
			@RequestParam(required = false, defaultValue = PAGE_SIZE) Integer pageSize,
			@RequestParam(required = false) String companyId, @RequestParam(required = false) String orderStatus,
			Model model) throws Exception {
		log.info("adOrderList.......");
		boolean companyHas = StringUtils.isNull(companyId);
		boolean orderStatusHas = StringUtils.isNotNull(orderStatus);
		User shiroUser = getShiroUser();
		Long companyId1 = shiroUser.getCompanyId();
		String companyId2 = companyId1.toString();

		// 根据公司id查询Order或者查询所有Order
		if (companyHas == true) {
			companyId = null;
		}
		if (companyId1 != 1) {
			companyId = companyId2;
		}
		String slotCount = null;
		String status = null;
		String proceed = null;

		if (orderStatusHas) {
			if (orderStatus.equals("1")) {
				slotCount = "0";
			}
			if (orderStatus.equals("2")) {
				status = "1";
				proceed="1";
			}
			if (orderStatus.equals("3")) {
				status = "2";
			}
		}
		Page<AdOrderListDTO> selectAdOrderPage = adOrderService.selectAdOrderPage(pageNum, pageSize, companyId,slotCount,status,proceed);
		List<AdOrderListDTO> adOrderList = selectAdOrderPage.getRecords();

		PageInfo<AdOrderListDTO> pageInfo = new PageInfo<AdOrderListDTO>(selectAdOrderPage);
		List<Company> allCompanyList = null;
		if (companyId1 == 1) {
			// 获取公司下拉框
			EntityWrapper<Company> entityWrapper = new EntityWrapper<>(new Company());
			entityWrapper.eq("status", 3).eq("deleted", 0).eq("company_type", 2);
			allCompanyList = companyService.selectList(entityWrapper);

		}
		if (log.isDebugEnabled()) {
			log.info("adOrderList......");
			log.debug("adOrderList...PAGE_NUM:{}", pageNum);
			log.debug("adOrderList...PAGE_SIZE:{}", pageSize);
			log.debug("adOrderList...companyId:{}", companyId);
			log.debug("adOrderList...result selectAdOrderPage size:{}", selectAdOrderPage.getRecords().size());
			if (allCompanyList != null) {
				log.debug("adOrderList...result allCompanyList size:{}", allCompanyList.size());
			}
		}
		model.addAttribute("companyId", companyId);
		model.addAttribute("companyList", allCompanyList);
		model.addAttribute("page", pageInfo);
		model.addAttribute("adOrderList", adOrderList);
		model.addAttribute("orderStatus", orderStatus);
		return "order/adOrderList";
	}

	/**
	 * 
	 * @Title: adOrderDetail  
	 * @Description: 订单详情
	 * @param pageNum
	 * @param pageSize
	 * @param orderId
	 * @param companyId
	 * @param styleId
	 * @param status
	 * @param model
	 * @return
	 * @throws Exception
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	// @RequiresPermissions(value = {
	// AuthorityConstants.Order.PERMISSION_ORDERLIST_DETAIL }, logical =
	// Logical.OR)
	@RequestMapping("/adOrderDetail")
	@SystemControllerLog(moduleName = { SYSTEM_MODULE }, description = "订单对应广告样式列表")
	public String adOrderDetail(@RequestParam(required = false, defaultValue = PAGE_NUM) Integer pageNum,
			@RequestParam(required = false, defaultValue = PAGE_SIZE) Integer pageSize,
			@RequestParam(required = false) String orderId, @RequestParam(required = false) String companyId,
			@RequestParam(required = false) String styleId,
			@RequestParam(required = false) String status,
			Model model) throws Exception {
		log.info("adOrderDetail......");
		boolean styleIdHas = StringUtils.isNull(styleId);
		boolean companyHas = StringUtils.isNull(companyId);
		User shiroUser = getShiroUser();
		Long companyId1 = shiroUser.getCompanyId();
		String companyId2 = companyId1.toString();

		// 根据公司id查询Order或者查询所有Order
		if (companyHas == true) {
			companyId = null;
		}
		if (companyId1 != 1) {
			companyId = companyId2;
		}
		if (styleIdHas == true) {
			styleId = null;
		}
		// 根据订单id获取对应的广告样式下拉框
		List<AdStyle> adStyleList = adStyleService.selectAdStyle(orderId);
		Page<OrderAdListDTO> allAdByOrderPage=null;
		if(status.equals("1")){
			// 获取订单详情列表
			 allAdByOrderPage = orderAdService.selectAllAdByOrderPage(pageNum, pageSize, orderId,
					styleId);
		}if(status.equals("2")){
			//获取完成订单的订单详情
			 allAdByOrderPage = orderAdService.selectAllAdPage(pageNum, pageSize, orderId,
						styleId);
		}
		
		List<OrderAdListDTO> orderAdList = allAdByOrderPage.getRecords();
		PageInfo<OrderAdListDTO> pageInfo = new PageInfo<OrderAdListDTO>(allAdByOrderPage);
		if (log.isDebugEnabled()) {
			log.info("adOrderDetail......");
			log.debug("adOrderDetail...PAGE_NUM:{}", pageNum);
			log.debug("adOrderDetail...PAGE_SIZE:{}", pageSize);
			log.debug("adOrderDetail...orderId:{}", orderId);
			log.debug("adOrderDetail...adStyleId:{}", styleId);
			log.debug("adOrderDetail...result allAdByOrderPage size:{}", allAdByOrderPage.getRecords().size());
			log.debug("adOrderDetail...result orderAdList size:{}", orderAdList.size());
		}
		model.addAttribute("page", pageInfo);
		model.addAttribute("orderAdList", orderAdList);
		model.addAttribute("adStyleList", adStyleList);
		model.addAttribute("orderId", orderId);
		model.addAttribute("styleId", styleId);
		model.addAttribute("companyId", companyId);
		model.addAttribute("status", status);
		return "order/listDetail";
	}

}
