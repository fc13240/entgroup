package com.entgroup.adms.controller;


import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.entgroup.adms.aop.SystemControllerLog;
import com.entgroup.adms.dto.DisplayCountDTO;
import com.entgroup.adms.model.system.Ad;
import com.entgroup.adms.model.system.AdDisplayCount;
import com.entgroup.adms.model.system.Company;
import com.entgroup.adms.model.system.User;
import com.entgroup.adms.util.PageInfo;
import com.entgroup.adms.vo.DataStatisticsVO;
import com.google.common.collect.Lists;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Date;
import java.util.List;

/**
 * @author mxy
 * @ClassName: AdDisplayCountController
 * @Description: TODO 统计数据展示
 * @date 2017-04-19 17:19
 */
@Controller
@RequestMapping("/adDisplayCount")
public class AdDisplayCountController extends BaseController {

    /**
     * 系统模块名
     */
    static final String SYSTEM_MODULE = "统计数据展示";

    /**
     * @param model
     * @param dataStatisticsVO
     * @param pageNum
     * @param pageSize
     * @return String
     * @throws
     *
     * @title adCount
     * @description TODO 统计数据-广告
     * @author mxy
     * @date 2017-04-19 17:23
     * @modifier
     * @remark
     * @version V1.0
     */
    @RequestMapping(value = "/adCount")
    @SystemControllerLog(moduleName = {SYSTEM_MODULE}, description = "统计数据-广告")
    public String adCount(
            Model model, @ModelAttribute DataStatisticsVO dataStatisticsVO,
            @RequestParam(required = false, defaultValue = PAGE_NUM) int pageNum,
            @RequestParam(required = false, defaultValue = PAGE_SIZE) int pageSize
    ) {
        log.info("adCount......");

        // 获取公司下拉框
        EntityWrapper<Company> entityWrapper = new EntityWrapper<>(
                new Company());
        entityWrapper.eq("status", 3).eq("deleted", 0).eq("company_type", 2);
        List<Company> allCompanyList = companyService.selectList(entityWrapper);

        Long companyId = long2Null(dataStatisticsVO.getCompanyId());
        Long adStyleId = long2Null(dataStatisticsVO.getAdStyleId());
        Long adId = long2Null(dataStatisticsVO.getAdId());
        Integer days = integer2Null(dataStatisticsVO.getDays());
        User shiroUser = getShiroUser();
        // 用于判断是否为管理员,若不为管理员（Admin==0），companyId=当前用户CompanyId
        if (shiroUser.getAdmin() == 0) {
            companyId = getShiroUser().getCompanyId();
        }
        if (days==null) {
            days=7;
        }
        Date adCountTimeStart = getDateBefore(new Date(),days);
        Date adCountTimeEnd = new Date();


        // 获取广告相关曝光信息（按日期统计）
        List<AdDisplayCount> adDisplayCounts = adDisplayCountService.getAdCountList4Chart(companyId,adId,adStyleId,
                                                                                          adCountTimeStart,adCountTimeEnd);
        // 根据获取广告相关曝光信息（按广告统计）
        Page<Ad> adPage = new Page(pageNum, pageSize);
        adPage.setOrderByField("ad_id");
        adPage.setAsc(false);
        adPage = adService.getAdCountList(adPage,companyId,adId,adStyleId,adCountTimeStart,adCountTimeEnd);

        int sumShowCount = 0;
        int sumUserCount = 0;
        for (AdDisplayCount adDisplayCount : adDisplayCounts) {
            Integer showCount = adDisplayCount.getShowCount();
            sumShowCount += showCount;
            Integer userCount = adDisplayCount.getUserCount();
            sumUserCount += userCount;
        }
        // 封装折线图DTO
        List<DisplayCountDTO> chartDTOList = Lists.newArrayList();
        for (AdDisplayCount adDisplayCount : adDisplayCounts) {
            DisplayCountDTO dto = new DisplayCountDTO();
            dto.setDayTime(adDisplayCount.getDayTime());
            dto.setSumShowCount(adDisplayCount.getShowCount()+"");
            dto.setSumUserCount(adDisplayCount.getUserCount()+"");
        }

        // 封装DTO
        List<DisplayCountDTO> dtoList = Lists.newArrayList();
        for (Ad ad : adPage.getRecords()) {
            DisplayCountDTO dto = new DisplayCountDTO();
            dto.setAdId(ad.getId());
            dto.setAdName(ad.getName());
            dto.setAdStyleId(ad.getAdStyle().getId());
            dto.setAdStyleName(ad.getAdStyle().getName());
            dto.setShowCount(ad.getShowCount());
            dto.setUserCount(ad.getUserCount());
            dtoList.add(dto);
        }

        PageInfo<Ad> page = new PageInfo(adPage);
        model.addAttribute("page", page);
        model.addAttribute("sumShowCount", sumShowCount);
        model.addAttribute("sumUserCount", sumUserCount);
        model.addAttribute("companyList", allCompanyList);
        model.addAttribute("chartDTOList", chartDTOList);
        model.addAttribute("dtoList", dtoList);
        //model.addAttribute("type", type);

        return "adDisplayCount/adCount";
    }
}