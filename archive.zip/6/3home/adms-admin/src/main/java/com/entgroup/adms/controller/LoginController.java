/**
 * @Title: HomeController.java
 * @Description: TODO(用一句话描述该文件做什么)
 * @author mengqch
 * @date 2015年9月4日
 * @version V1.0
 */
package com.entgroup.adms.controller;

import com.entgroup.adms.conf.AdmsConstants;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.web.filter.authc.FormAuthenticationFilter;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;

/**
 * @author hpb
 * @Description:
 * @date 2017/2/28
 */
@Controller
public class LoginController extends BaseController {

    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String login() {
        log.debug("login...");
        // 如果用户直接到登录页面 先退出一下
        // 原因：isAccessAllowed实现是subject.isAuthenticated()---->即如果用户验证通过 就允许访问
        // 这样会导致登录一直死循环
        Subject subject = SecurityUtils.getSubject();
        if (subject != null && subject.isAuthenticated()) {
            if (log.isDebugEnabled()) {
                log.debug("logout....");
            }
            removeSession(AdmsConstants.SESSION_USER_KEY);
            subject.logout();
        }
        return "login";
    }

    @RequestMapping(value = "/home", method = RequestMethod.GET)
    public String home(HttpServletRequest request) {
        //TODO 根据用户角色判断跳转页面-
        return "home";
    }

    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public String fail(@RequestParam(FormAuthenticationFilter.DEFAULT_USERNAME_PARAM) String userName, Model model) {
        model.addAttribute(FormAuthenticationFilter.DEFAULT_USERNAME_PARAM, userName);
        model.addAttribute("errorMessage", "*用户|密码输入错误");
        return "login";
    }

}
