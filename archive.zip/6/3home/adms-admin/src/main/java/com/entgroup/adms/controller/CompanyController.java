package com.entgroup.adms.controller;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.entgroup.adms.aop.SystemControllerLog;
import com.entgroup.adms.conf.AuthorityConstants;
import com.entgroup.adms.model.JsonResult;
import com.entgroup.adms.model.system.*;
import com.entgroup.adms.util.PageInfo;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.net.ntp.TimeStamp;
import org.apache.shiro.authz.annotation.Logical;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * @author xiaokun
 * @ClassName: CompanyController
 * @Description: 客户管理
 * @date 2017-03-19 14:39
 */
@Controller
@RequestMapping("/company")
public class CompanyController extends BaseController {
    /**
     * 系统模块名
     */
    private static final String SYSTEM_MODULE = "客户管理";

    /**
     * @title companyList
     * @description TODO 查询客户列表
     * @author xiaokun
     * @date 2017-03-24 14:39
     * @modifier
     * @remark
     * @version V1.0
     *
     * @param pageNum
     * @param pageSize
     * @param company
     * @param model
     * @return String
     * @throws
     */
    @RequiresPermissions(value = {AuthorityConstants.CompanyAndUser.VIEW_COMPANYANDUSER_COMPANYLIST}, logical = Logical.OR)
    @RequestMapping("/companyList")
    @SystemControllerLog(moduleName = {SYSTEM_MODULE}, description = "查询客户列表")
    public String companyList(@RequestParam(required = false, defaultValue = PAGE_NUM) int pageNum,
                                 @RequestParam(required = false, defaultValue = PAGE_SIZE) int pageSize,
                                 @ModelAttribute("company") Company company, Model model) {

        this.log.info("companyList......");

        // 筛选框参数-企业分类
        List<CompanyVocation> companyVocationList = companyVocationService.selectList(null);
        List<Company> companyList;

        // 分页信息
        Page<Company> companyPage = new Page<>(pageNum, pageSize);
        companyPage.setOrderByField("id");
        companyPage.setAsc(false);
        companyPage = companyService.getAllCompanies(companyPage, company);
        companyPage.setOrderByField("id");
        companyPage.setAsc(false);
        companyList = companyPage.getRecords();

        for (Company companyTemp : companyList) {
            // 赋值用户总数
            if (null == company.getUserIds()) {
                companyTemp.setOrderCount(0);
            } else {
                companyTemp.setUserCount(StringUtils.countMatches(companyTemp.getUserIds(), ",")+1);
            }
            // 赋值订单总数
            if (null == companyTemp.getOrderIds()) {
                companyTemp.setOrderCount(0);
            } else {
                companyTemp.setOrderCount(StringUtils.countMatches(companyTemp.getOrderIds(), ",")+1);
            }
            // 赋值处理中订单数
            companyTemp.setOrderOnDeal(StringUtils.countMatches(companyTemp.getOrderIds(), "-1"));
        }
        // 页面传值
        PageInfo<Company> page = new PageInfo<>(companyPage);
        model.addAttribute("companyList", companyList);
        model.addAttribute("page", page);
        model.addAttribute("companyVocationList", companyVocationList);

        // 日志记录
        if (log.isDebugEnabled()) {
            log.info("companyList......");
            log.debug("companyList...pageNum:{}", pageNum);
            log.debug("companyList...pageSize:{}", pageSize);
            log.debug("companyList...param company toString:{}", company);
            log.debug("companyList...result companyList size:{}", companyPage.getRecords().size());
            log.debug("companyList...result page total:{}", page.getTotal());
        }
        return "company/companyList";
    }

    /**
     * @title saveCompany
     * @description TODO 保存客户信息(新增/修改)
     * @author xiaokun
     * @date 2017-04-13 14:12
     * @modifier
     * @remark
     * @version V1.1
     *
     * @param
     * @return JsonResult
     * @throws
     */
    @RequiresPermissions(value = {AuthorityConstants.CompanyAndUser.PERMISSION_COMPANYLIST_SAVECOMPANY}, logical = Logical.OR)
    @ResponseBody
    @RequestMapping("/saveCompany")
    @SystemControllerLog(moduleName = {SYSTEM_MODULE}, description = "保存客户信息")
    public JsonResult saveCompany(@ModelAttribute("company") Company company) {

        log.info("saveCompany......");

        // 获取当前登录用户信息
        User shiroUser = getShiroUser();
        Integer admin = shiroUser.getAdmin();

        // 判断对象属性非空
        String msg = companyIsNull(company);
        if (null != msg) {
            jr = renderError(msg);
            return jr;
        }
        // 判断区分新增/修改
        if (null != company.getId()) { // 修改
            // 判断改名是否重复
            String newCompanyName = company.getCompanyName();
            Company conflictCompany = null;
            try {
                conflictCompany = companyService.selectOne(new EntityWrapper<Company>().where("company_name='"+newCompanyName+"'").and("id!="+company.getId()).orNew("short_name='"+newCompanyName+"'").and("id!="+company.getId()));
                if (null != conflictCompany) {
                    jr = renderError("该客户已存在");
                    return jr;
                }
            } catch (Exception e) {
                e.printStackTrace();
                jr = renderError("客户修改查重异常");
                return jr;
            }

            // 修改信息
            try {
                companyService.updateById(company);
                jr = renderSuccess("修改客户信息成功");
            } catch (Exception e) {
                e.printStackTrace();
                jr = renderError("修改客户信息异常");
                return jr;
            }
        } else { // 新增
            // 校验数据库中不存在此客户
            String newCompanyName = company.getCompanyName();
            Company conflictCompany = null;
            try {
                conflictCompany = companyService.selectOne(new EntityWrapper<Company>().where("company_name='"+newCompanyName+"'").or("short_name='"+newCompanyName+"'"));
                if (null != conflictCompany) {
                    jr = renderError("该客户已存在");
                    return jr;
                }
            } catch (Exception e) {
                e.printStackTrace();
                jr = renderError("客户添加查重异常");
                return jr;
            }
            // 根据权限不同赋值审核状态
            if (admin == 1) {
                company.setStatus(3);
            } else {
                company.setStatus(1);
            }
            company.setCreated(TimeStamp.getCurrentTime().getDate());
            // 预留company_type存储 (默认为广告平台)
            if (null == company.getCompanyType()) {
                company.setCompanyType(2);
            }
            // 存储信息
            try {
                companyService.insert(company);
                jr = renderSuccess("新建客户信息成功");
            } catch (Exception e) {
                e.printStackTrace();
                jr = renderError("新建客户信息异常");
                return jr;
            }
        }
        // 日志记录
        if (log.isDebugEnabled()) {
            log.info("saveCompany......");
            log.debug("saveCompany...param company toString:{}", company.toString());
            log.debug("saveCompany...result jr toString:{}", jr.toString());
        }
        return jr;
    }

    /**
     * @title selectOne
     * @description TODO 查询客户详情
     * @author xiaokun
     * @date 2017-04-02 10:24
     * @modifier
     * @remark
     * @version V1.0
     *
     * @param companyId
     * @return JsonResult
     * @throws
     */
    @RequiresPermissions(value = {AuthorityConstants.CompanyAndUser.PERMISSION_COMPANYLIST_COMPANYDETAIL}, logical = Logical.OR)
    @RequestMapping("/selectOne")
    @ResponseBody
    @SystemControllerLog(moduleName = {SYSTEM_MODULE}, description = "查询客户详情")
    public JsonResult selectOne(@RequestParam("companyId") Long companyId) {

        log.info("selectOne......");

        Company company = companyService.selectById(companyId);

        if (null != company.getId()) {
            jr = renderSuccess("获取成功");
        } else {
            jr = renderError("获取失败");
        }
        jr.setData("company", company);
        if (log.isDebugEnabled()) {
            log.info("selectOne......");
            log.debug("selectOne...param companyId:{}", companyId);
            log.debug("selectOne...result company toString:{}", company.toString());
        }
        return jr;
    }

    public String companyIsNull(Company company) {
        String msg = null;
        if (null == company.getCompanyName() || company.getCompanyName() == "") {
            msg = "请填写客户全称";
        } else if (null == company.getShortName() || company.getShortName() == "") {
            msg = "请填写客户简称";
        } else if (null == company.getCompanyVocationId()) {
            msg = "请选择所属行业";
        } else if (null == company.getContact() || company.getContact() == "") {
            msg = "请填写联系人";
        } else if (null == company.getPhoneNumber() || company.getPhoneNumber() == "") {
            msg = "请填写联系电话";
        } else if (null == company.getEmail() || company.getEmail() == "") {
            msg = "请填写联系人邮箱";
        }
        return msg;
    }
}
