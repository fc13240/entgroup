$(function() {

	function goBack() {
		window.history.go(0)
	}

	$("#comList").click(function() {
	var companyId = $(this).val();
	$.ajax({
			type : "GET",
			async : false,
			contentType : "application/json",
			url : ADMS.ctx + "/order/selectAdStyle",
			data : {
				"companyId" : companyId
			},
			dataType : "json",
			scriptCharset : 'utf-8',
			success : function(result) {
					$("#saveAdOrder").removeAttr("value");
				var trs = "";
				trs+="<table  class="+'"'+'no-style'+'"'+">";
				if(result.adListByCompany.length==0){
					var trs1="<li style="+'"'+'line-height: 162px;width: 100%;text-align: center;color:red;font-size: 16px;'+'"'+">请先联系客户制作广告，广告审核通过后才可建立订单</li>";
				}
	        $.each(result.adListByCompany,function(n, value) {
				trs += "<tr><td style='width:50px;'><div class='piaochecked on_check '>";
				trs += "<input name='need_inv' type='checkbox' style='height:20px;width:20px;' class='radioclass input' value="
						+ value.adId
						+ "></td>";
				trs += "</div>";
				trs += "<td style='width:100px;'>"
						+ value.adName+"</td><td style='width:100px;'>"
						+ value.styleName+"</td><td style='width:100px;'>"
						+ value.date+"</td>"
						+ "</tr>";
			});
	        trs+="</table>";
	        	$("#ad-id").html(trs);
	        	$("#ad-id").html(trs1);
	        	 $("#saveOrderModal").delegate('.piaochecked', 'click', function(){
						$(this).toggleClass("on_check");
										if ($(this).children("input:first").attr("checked")) {
											$(this).children("input:first").removeAttr("checked");
										} else {
											$(this).children("input:first").attr("checked",'true');
										}
										 var chooseNum = checkJust()[1];
								         if(chooseNum > 0&&selectTotal>0){
								 			 $("#saveAdOrder").removeAttr("disabled");
								 			 $("#saveAdOrder").removeClass("unclick");
								 		}else{
								 			$("#saveAdOrder").attr("disabled",true);
								 			 $("#saveAdOrder").addClass("unclick");
								 		}
									});
									},
									cache : false,
									error : function(result) {
										alert("获取广告失败");
									}
								});

	});
	var selectTotal=0

	function checkJust(){
		var adId="";
		var selectNum=0;
		$("input[name='need_inv'][checked]").each(function(){
			adId += $(this).val()+",";
 			selectNum +=1;
 		});
		return new Array(adId,selectNum);
	}
	// 金额校验
    $("#totalMoney").blur(function () {
        if (!$("#totalMoney").val()) {
            $("#totalMoney").html("*请输入金额");
            $("#saveAdOrder").attr("disabled", "disabled");
            selectTotal=0;
        } else if (!isDigit($("#totalMoney").val())) {
            $("#totalMoney").html("*请输入数字");
            $("#saveAdOrder").attr("disabled", "disabled");
            selectTotal=0;  
        }else if($("#totalMoney").val().length> 9){
        	$("#saveAdOrder").attr("disabled", "disabled");
        	selectTotal=0;
        }else{
        	var chooseNum = checkJust()[1];
        	selectTotal=1;
        	if(chooseNum>0){
        		 $("#saveAdOrder").removeAttr("disabled");
        		 $("#saveAdOrder").removeClass("unclick");
        	}
        }
    });
	// edited by mxy on 2017-04-15 11:47 begin
	$('#saveAdOrder').one('click', function() {
		var companyId = $('#comList').val();
		var remark = $('#remark').val();
		var adIds = checkJust()[0];
		var totalMoney = $("#totalMoney").val();
		$.getJSON(ADMS.ctx + '/order/saveAdOrder', $.param({
			'companyId' : companyId,
			'adIds' : adIds,
			'remark' : encodeURIComponent(remark),
//			'remark' : remark,
			'totalMoney' : totalMoney,
		}, true), function(resp) {
			 hideModal('saveOrderModal');
			if (resp['success']) {
				showpromptModal(resp['msg'],true,3000,false,function(){
					window.location.href = ADMS.ctx + "/order/adOrderList?companyId=" + companyId;
				});
			} else {
				showpromptModal(resp['msg'],false,3000,false,function(){
					window.location.href = ADMS.ctx + "/order/adOrderList?companyId=" + companyId;
				});
			}
		});
		
	});
	//edited by mxy on 2017-04-15 11:47 end
	$("#updateOrderSlot").click(function(){
		var companyId = $('#comList').val();
		$.ajax( {
			  type: "GET",
			  async:false,
			  contentType : "application/json",
			  url: ADMS.ctx + "/order/updateOrderSlot",
			  dataType: "json", 
			  scriptCharset: 'utf-8',
			  success: function(resp) {
				  showpromptModal(resp['msg'],true,3000,false,function(){
					  window.location.href = ADMS.ctx + "/order/adOrderList?companyId=" + companyId;
				  });
			  },
			  cache: false,
			  error:function(result){ 
		      alert("修改广告位失败");
             } 
	        });
		
	});
});