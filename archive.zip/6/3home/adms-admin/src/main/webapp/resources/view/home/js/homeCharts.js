/**
 * Created by sth on 2017/6/1.
 */

var homeChart = echarts.init(document.getElementById('chartMain'));

// 指定图表的配置项和数据
var homeOption = {
    title: {
        text: ''
    },
    tooltip: {
        trigger: 'axis'
    },
    legend: {
        data:['曝光量','曝光人数']
    },
    grid: {
        left: '10%',
        right: '10%',
        bottom: '10%',
        containLabel: true
    },
    xAxis: {
        type: 'category',
        boundaryGap: false,
        data: [ '2009/6/1', '2009/6/2', '2009/6/3', '2009/6/4', '2009/6/5', '2009/6/6', '2009/6/7']
    },
    yAxis: {
        type: 'value'
    },
    series: [
        {
            name:'曝光量',
            type:'line',
            stack: '曝光量',
            data:[4600, 5100, 2000, 3600, 1000, 1000, 2000]
        },
        {
            name:'曝光人数',
            type:'line',
            stack: '曝光人数',
            data:[5001, 2000, 4400, 3600, 3010, 3510, 4200]
        }
    ]
};

// 使用刚指定的配置项和数据显示图表。
homeChart.setOption(homeOption);

// 异步加载数据
$.get('data.json').done(function (data) {
    // 填入数据
    homeChart.setOption({
        xAxis: {
            data: data.categories
        },
        series: [{
            // 根据名字对应到相应的系列
            name: '曝光量',
            data: data.data
        },{
            // 根据名字对应到相应的系列
            name: '曝光人数',
            data: data.data
        }]
    });
});