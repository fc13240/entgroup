package controller;

import org.junit.Test;

/**
 * @author xiaokun
 * @className NoticeControllerTest
 * @description 通知管理测试
 * @create 2017/3/31 12:20
 */
public class NoticeControllerTest {

    /**
     * @title testFormatNotice
     * @description TODO 测试notice.properties读取
     * @author xiaokun
     * @date 2017-03-31 16:08
     * @modifier
     * @remark
     * @version V1.0
     *
     * @param
     * @return void
     * @throws Exception
     */
    /*@Test
    public void testFormatNotice() throws Exception {
        NoticeConfig.INoticeConfig config = NoticeConfig.config;
        String body = config.auditContent();
        String param1 = "香飘飘";
        String param2 = config.noPass();
        String a = String.format(body, param1, param2);
        //String a = body.replace("null", param2);
        System.err.println(a);
    }*/
}
