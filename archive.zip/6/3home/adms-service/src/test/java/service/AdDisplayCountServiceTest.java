package service;

import java.io.FileOutputStream;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Test;

import com.baomidou.mybatisplus.plugins.Page;
import com.entgroup.adms.dto.DisplayCountDTO;
import com.entgroup.adms.model.system.AdDisplayCount;
import com.entgroup.adms.service.AdDisplayCountService;

public class AdDisplayCountServiceTest extends
		BaseServiceTest<AdDisplayCountService> {
	/**
	 * 
	 * @method: testStaOrderCosumeList
	 * @description: 统计订单消费金额
	 * @author guofei
	 * @date 2017-4-21
	 */
	@Test
	public void testStaOrderCosumeList() {
		List<DisplayCountDTO> staOrderCosumeList = service
				.staOrderCosumeList("2017-03-22");
		System.out.println(staOrderCosumeList);
	}

	/**
	 * 
	 * @method: testSelectAdAndCountPage
	 * @description: 统计页面adCount
	 * @author guofei
	 * @date 2017-4-21
	 */
	@Test
	public void testSelectAdAndCountPage() {
		Page<DisplayCountDTO> selectAdAndCount = service.selectAdAndCountPage(
				1, 8, null,"31120170426144713", null, null, "2017-03-07");
		List<DisplayCountDTO> records = selectAdAndCount.getRecords();
		System.out.println(records);
	}

	/**
	 * 
	 * @method: testGetWorkBook
	 * @description: adCount生成excel
	 * @throws Exception
	 * @author guofei
	 * @date 2017-4-21
	 */
	@Test
	public void testGetWorkBook() throws Exception {
		HSSFWorkbook workBook = service.getUserWorkBook("1",null, null, null, "7",
				"2017-02-22");
		// 5.将HSSFWorkbook生成为Excel文件
		FileOutputStream fos = new FileOutputStream("g://test.xls");
		workBook.write(fos);
		fos.close();
	}

	@Test
	public void testSelectCountPlatPage() {
		Page<DisplayCountDTO> selectCountPlatPage = service
				.selectCountPlatPage(1, 2, null,"1", null, "1", "2017-03-07");
		List<DisplayCountDTO> records = selectCountPlatPage.getRecords();
		System.out.println(records);
	}

	@Test
	public void testGetPlatWorkBook() throws Exception {
		HSSFWorkbook workBook = service.getPlatWorkBook("1", null,null, null, "7",
				"2017-02-22");
		// 5.将HSSFWorkbook生成为Excel文件
		FileOutputStream fos = new FileOutputStream("g://test.xls");
		workBook.write(fos);
		fos.close();
	}

	/**
	 * 
	 * @method: testSelectDisplayCount
	 * @description: 获取前一天曝光量和用户量
	 * @author guofei
	 * @date 2017-4-21
	 */
	@Test
	public void testSelectDisplayCount() {
		List<AdDisplayCount> selectDisplayCount = service.selectDisplayCount(
				"2017-03-29 00:00:00", "2017-03-30 00:00:00");
		System.out.println(selectDisplayCount);
	}

}
