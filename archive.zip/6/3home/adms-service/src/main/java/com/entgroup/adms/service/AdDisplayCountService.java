package com.entgroup.adms.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;
import com.entgroup.adms.dto.DisplayCountDTO;
import com.entgroup.adms.model.system.AdDisplayCount;
import com.entgroup.adms.model.system.AdOrder;
import com.entgroup.adms.model.system.OrderAd;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 日曝光统计 服务类
 * </p>
 * 
 * @author hpb
 * @since 2017-03-08
 */
public interface AdDisplayCountService extends IService<AdDisplayCount> {
	/**
	 * 
	 * @Title: staOrderCosumeList  
	 * @Description: 获取订单前一天的消费金额 
	 * @param beforeDay
	 * @return
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	List<DisplayCountDTO> staOrderCosumeList(String beforeDay);

	/**
	 * 
	 * @Title: selectAdAndCountPage  
	 * @Description: 根据公司id查询 广告的曝光量 
	 * @param pageNum
	 * @param pageSize
	 * @param companyId
	 * @param adOrderId
	 * @param adStyleId
	 * @param adId
	 * @param beforeDay
	 * @return
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	Page<DisplayCountDTO> selectAdAndCountPage(int pageNum, int pageSize,
			String companyId,String adOrderId, String adStyleId, String adId, String beforeDay);

	/**
	 * 
	 * @Title: getUserWorkBook  
	 * @Description: 获取广告页面excel表格
	 * @param companyId
	 * @param adOrderId
	 * @param adStyleId
	 * @param adId
	 * @param days
	 * @param beforeDay
	 * @return
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	HSSFWorkbook getUserWorkBook(String companyId,String adOrderId, String adStyleId,
			String adId, String days, String beforeDay);

/**
 * 
 * @Title: selectCountPlatPage  
 * @Description:分页获取平台统计数据 
 * @param pageNum
 * @param pageSize
 * @param companyId
 * @param adOrderId
 * @param adStyleId
 * @param adId
 * @param beforeDay
 * @return
 * @author guofei 
 * @date 2017年5月5日
 */
	Page<DisplayCountDTO> selectCountPlatPage(int pageNum, int pageSize,
			String companyId,String adOrderId, String adStyleId, String adId, String beforeDay);
/**
 * 
 * @Title: getPlatWorkBook  
 * @Description:获取平台统计数据导出excel表格 
 * @param companyId
 * @param adOrderId
 * @param adStyleId
 * @param adId
 * @param days
 * @param beforeDay
 * @return
 * @author guofei 
 * @date 2017年5月5日
 */
	HSSFWorkbook getPlatWorkBook(String companyId,String adOrderId, String adStyleId,
			String adId, String days, String beforeDay);

	/**
	 * 
	 * @Title: selectDisplayCount  
	 * @Description: 统计前一天的曝光量和用户量  
	 * @param beforeDay
	 * @param nowDay
	 * @return
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	List<AdDisplayCount> selectDisplayCount(String beforeDay, String nowDay);

	/**
	 * 
	 * @Title: selectCountForLine  
	 * @Description: 生成统计折线图 
	 * @param companyId
	 * @param adOrderId
	 * @param adStyleId
	 * @param adId
	 * @param beforeDay
	 * @return
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	List<DisplayCountDTO> selectCountForLine(String companyId,String adOrderId,
			String adStyleId, String adId, String beforeDay);

	/**
	 * 
	 * @Title: selectCountForPlat  
	 * @Description: 饼图获取数据 
	 * @param companyId
	 * @param adOrderId
	 * @param adStyleId
	 * @param adId
	 * @param beforeDay
	 * @return
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	List<DisplayCountDTO> selectCountForPlat(String companyId,String adOrderId,
			String adStyleId, String adId, String beforeDay);

	/**
	 * @param companyId
	 * @param adId
	 * @param adStyleId
	 * @param tortTimeStart
	 * @param tortTimeEnd
	 * @return List<AdDisplayCount>
	 * @throws
	 * 
	 * @title getAdCountList4Chart
	 * @description TODO 获取广告相关曝光信息（按日期统计）
	 * @author mxy
	 * @date 2017-04-19 16:43
	 * @modifier
	 * @remark
	 * @version V1.0
	 */
	List<AdDisplayCount> getAdCountList4Chart(Long companyId, Long adId,
			Long adStyleId, Date tortTimeStart, Date tortTimeEnd);
	/**
	 * 
	 * @Title: selectCountForPlatChart  
	 * @Description: 获取平台统计图  
	 * @param companyId
	 * @param adOrderId
	 * @param adStyleId
	 * @param adId
	 * @param beforeDay
	 * @return
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	List<DisplayCountDTO> selectCountForPlatChart(String companyId, String adOrderId, String adStyleId, String adId,
			String beforeDay);
	//FIXME 以下为测试统计订单金额  之后需要删除======================================================================
	
	
	/**
	 * 
	 * @Title: selectOneAdOrder  
	 * @Description:根据订单id获取订单     （统计订单金额  之后删除） 
	 * @param orderId
	 * @return
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	AdOrder selectOneAdOrder(String orderId);
	/**
	 * 
	 * @Title: updateAdByOrderId  
	 * @Description:  删除广告位和广告关联表  
	 * @param orderIdList
	 * @return
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	boolean updateAdByOrderId(List<String> orderIdList);
	/**
	 * 
	 * @Title: deleteOrderAd  
	 * @Description: 删除订单广告关联表
	 * @param orderIdList
	 * @return
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	boolean deleteOrderAd(List<String> orderIdList);
	/**
	 * 
	 * @Title: updateBatchAdOrderById  
	 * @Description: 完成订单 将订单 delete设置为1 
	 * @param adOrderList
	 * @return
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	boolean updateBatchAdOrderById(List<AdOrder> adOrderList);
	/**
	 * 
	 * @Title: addAdOrderNotice  
	 * @Description: 添加订单完成通知  
	 * @param selectOneOrder
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	void addAdOrderNotice(AdOrder selectOneOrder);
	/**
	 * 
	 * @Title: selectOrderAdList  
	 * @Description:获取订单广告关联表 
	 * @param orderId
	 * @return
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	List<OrderAd> selectOrderAdList(String orderId);
	/**
	 * 
	 * @Title: updateBatchAd  
	 * @Description:批量重启广告  
	 * @param adIdList
	 * @return
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	boolean updateBatchAd(List<String> adIdList);
	//以上为测试统计订单金额  之后需要删除======================================================================




}
