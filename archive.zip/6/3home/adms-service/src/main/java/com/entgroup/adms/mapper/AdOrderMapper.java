package com.entgroup.adms.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.entgroup.adms.dto.AdAndStyleByCompanyDTO;
import com.entgroup.adms.dto.AdOrderListDTO;
import com.entgroup.adms.model.system.AdOrder;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

/**
 * <p>
  * 订单 Mapper 接口
 * </p>
 *
 * @author hpb
 * @since 2017-03-08
 */
public interface AdOrderMapper extends BaseMapper<AdOrder> {
	/**
	 * 
	 * @Title: selectAdOrderPage  
	 * @Description: 获取订单列表 
	 * @param pagination
	 * @param companyId
	 * @param slotCount
	 * @param status
	 * @param proceed
	 * @return
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	List<AdOrderListDTO> selectAdOrderPage(Pagination pagination, @Param("companyId")String companyId, @Param("slotCount")String slotCount,@Param("status") String status,@Param("proceed") String proceed);

	
	/**
	 * 
	 * @Title: updateAdOrderSlotCount  
	 * @Description: 修改广告订单 的广告位总数  
	 * @param adId
	 * @return
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	boolean updateAdOrderSlotCount(Long adId);

	/**
	 * 
	 * @Title: insertAdOrder  
	 * @Description: 添加订单  
	 * @param adOrder
	 * @return
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	int insertAdOrder(AdOrder adOrder);

	/**
	 * 
	 * @Title: selectOrderList  
	 * @Description:  获取统计页面订单下拉框  
	 * @param companyId
	 * @return
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	List<AdAndStyleByCompanyDTO> selectOrderList(@Param("companyId")String companyId);
}
