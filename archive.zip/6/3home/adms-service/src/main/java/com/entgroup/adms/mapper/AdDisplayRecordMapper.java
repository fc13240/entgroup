package com.entgroup.adms.mapper;

import com.entgroup.adms.model.system.AdDisplayRecord;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author hpb
 * @since 2017-03-08
 */
public interface AdDisplayRecordMapper extends BaseMapper<AdDisplayRecord> {


}
