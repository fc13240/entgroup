package com.entgroup.adms.service;

import com.entgroup.adms.model.system.PlatformPrice;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author MaxNull
 * @since 2017-05-05
 */
public interface PlatformPriceService extends IService<PlatformPrice> {
	
}
