package com.entgroup.adms.mapper;

import com.entgroup.adms.model.system.AdReason;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author hpb
 * @since 2017-03-08
 */
public interface AdReasonMapper extends BaseMapper<AdReason> {

}
