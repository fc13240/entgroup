package com.entgroup.adms.model.system;

import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.annotations.TableName;
import com.entgroup.adms.model.BaseObject;

import java.util.Date;


/**
 * <p>
 * 订单
 * </p>
 *
 * @author hpb
 * @since 2017-03-08
 */
@TableName("sys_ad_order")
public class AdOrder extends BaseObject {

    private static final long serialVersionUID = 1L;
	public static final int STATUS_ON=1;//进行中
	public static final int STATUS_COMPLETE=2;//交易完成

    /**
     * 订单编号(生成规则：companyId+userId+时间20170314012323)
     */
	private String id;
	@TableField("company_id")
	private Long companyId;
    /**
     * 广告总数
     */
	@TableField("ad_count")
	private Integer adCount;
    /**
     * 广告位总数
     */
	@TableField("slot_count")
	private Long slotCount;
    /**
     * 总金额（元）
     */
	@TableField("total_money")
	private Integer totalMoney;
    /**
     * 消费金额,每天统计进行累计
     */
	@TableField("cosume_money")
	private Integer cosumeMoney;
    /**
     * 1-进行中，2-交易完成
     */
	private Integer status;
	/**
	 * 创建时间
	 */
	private Date created;
	/**
	 * 备注
	 */
	private String remark;

	@TableField(exist=false)
	private String adIds;
	
	
	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getAdIds() {
		return adIds;
	}

	public void setAdIds(String adIds) {
		this.adIds = adIds;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	public Integer getAdCount() {
		return adCount;
	}

	public void setAdCount(Integer adCount) {
		this.adCount = adCount;
	}

	public Long getSlotCount() {
		return slotCount;
	}

	public void setSlotCount(Long slotCount) {
		this.slotCount = slotCount;
	}

	public Integer getTotalMoney() {
		return totalMoney;
	}

	public void setTotalMoney(Integer totalMoney) {
		this.totalMoney = totalMoney;
	}

	public Integer getCosumeMoney() {
		return cosumeMoney;
	}

	public void setCosumeMoney(Integer cosumeMoney) {
		this.cosumeMoney = cosumeMoney;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

}

