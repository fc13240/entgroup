package com.entgroup.adms.service;

import com.entgroup.adms.model.system.ProgramLevel;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 * 节目等级表 服务类
 * </p>
 *
 * @author hpb
 * @since 2017-03-08
 */
public interface ProgramLevelService extends IService<ProgramLevel> {
	
}
