package com.entgroup.adms.service;

import com.entgroup.adms.model.system.AdType;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author hpb
 * @since 2017-03-08
 */
public interface AdTypeService extends IService<AdType> {
	
}
