package com.entgroup.adms.service;

import com.entgroup.adms.model.system.ActiveCode;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 * 激活验证表 服务类
 * </p>
 *
 * @author hpb
 * @since 2017-03-08
 */
public interface ActiveCodeService extends IService<ActiveCode> {
	
}
