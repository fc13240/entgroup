package com.entgroup.adms.service;

import com.entgroup.adms.model.system.ProgramType;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 * 视频类型 服务类
 * </p>
 *
 * @author hpb
 * @since 2017-03-08
 */
public interface ProgramTypeService extends IService<ProgramType> {
	
}
