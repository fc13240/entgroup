/**     
 * @Project: adms-service  
 * @Title: AddressInfoDTO.java
 * @Description: TODO(用一句话描述该文件做什么)   
 * @Author: mqc
 * @Date: 2016-6-5 下午5:00:03   
 * @Version: V1.0     
 */
package com.entgroup.adms.dto;

import java.util.List;

import com.entgroup.adms.model.system.Person;
import com.entgroup.adms.model.system.Scene;

/**
 * @author mxy
 * @ClassName: AdSlotDTO
 * @Description: 广告位信息
 * @date 2017-03-24 20:48
 */
public class AdSlotDTO {

	/**
	 * 入库时间
	 */
	private String created;

	/**
	 * 视频id
	 */
	private Long videoId;

	/**
	 * 视频名称
	 */
	private String videoName;

	/**
	 * 视频时间点(s)
	 */
	private String videoPosition;

	/**
	 * 画面所在服务器
	 */
	private String imageServer;

	/**
	 * 状态 0-无广告位，1-有广告位，2-广告位已有广告。
	 */
	private Integer status = 0;

	/**
	 * 标签集合
	 */
	private List<LabelDTO> labelDTOList;
	
	
	
	public String getCreated() {
		return created;
	}

	public void setCreated(String created) {
		this.created = created;
	}

	public Long getVideoId() {
		return videoId;
	}

	public void setVideoId(Long videoId) {
		this.videoId = videoId;
	}

	public String getVideoName() {
		return videoName;
	}

	public void setVideoName(String videoName) {
		this.videoName = videoName;
	}

	public String getVideoPosition() {
		return videoPosition;
	}

	public void setVideoPosition(String videoPosition) {
		this.videoPosition = videoPosition;
	}

	public String getImageServer() {
		return imageServer;
	}

	public void setImageServer(String imageServer) {
		this.imageServer = imageServer;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public List<LabelDTO> getLabelDTOList() {
		return labelDTOList;
	}

	public void setLabelDTOList(List<LabelDTO> labelDTOList) {
		this.labelDTOList = labelDTOList;
	}

	//edited by mxy on 2017-03-29 15:59 begin
	/**
	 * 图片地址
	 */
	private String pictureAddress;

	/**
	 * 视频时间点(mm:ss)
	 */
	private String videoPositionTime;

	public String getPictureAddress() {
		return pictureAddress;
	}
	public void setPictureAddress(String pictureAddress) {
		this.pictureAddress = pictureAddress;
	}

	public String getVideoPositionTime() {
		return videoPositionTime;
	}

	public void setVideoPositionTime(String videoPositionTime) {
		this.videoPositionTime = videoPositionTime;
	}
	//edited by mxy on 2017-03-29 15:59 end
	//edited by mxy on 2017-03-30 10:05 begin
	/**
	 * 广告位id
	 */
	private Long adSlotId;

	public Long getAdSlotId() {
		return adSlotId;
	}

	public void setAdSlotId(Long adSlotId) {
		this.adSlotId = adSlotId;
	}
	//edited by mxy on 2017-03-30 10:06 end
}
