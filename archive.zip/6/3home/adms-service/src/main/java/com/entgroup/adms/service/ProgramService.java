package com.entgroup.adms.service;

import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.IService;
import com.entgroup.adms.model.system.Program;

/**
 * <p>
 * 节目表 服务类
 * </p>
 *
 * @author hpb
 * @since 2017-03-08
 */
public interface ProgramService extends IService<Program> {

    /**
     * @param page
     * @param name
     * @param companyId
     * @param typeId
     * @param levelId
     *
     * @return Page<Program>
     *
     * @throws ???
     * @title getProgramPriceList
     * @description TODO 获取节目价格信息列表
     * @author mxy
     * @date 2017-03-21 10:29
     * @modifier
     * @remark
     * @version V1.0
     */
    Page<Program> getProgramPriceList(
            Page<Program> page, String name, Long companyId, Long typeId,
            Integer levelId
    );
}
