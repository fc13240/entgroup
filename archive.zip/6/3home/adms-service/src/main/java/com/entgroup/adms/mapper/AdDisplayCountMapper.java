package com.entgroup.adms.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;
import com.entgroup.adms.dto.DisplayCountDTO;
import com.entgroup.adms.model.system.AdDisplayCount;
import com.entgroup.adms.model.system.AdOrder;

import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 日曝光统计 Mapper 接口
 * </p>
 * 
 * @author hpb
 * @since 2017-03-08
 */
public interface AdDisplayCountMapper extends BaseMapper<AdDisplayCount> {
/**
 * 
 * @Title: staOrderCosumeList  
 * @Description:  获取前一天的消费金额列表  
 * @param beforeDay
 * @return
 * @author guofei 
 * @date 2017年5月5日
 */
	List<DisplayCountDTO> staOrderCosumeList(String beforeDay);

	/**
	 * 
	 * @Title: selectAdAndCount  
	 * @Description: 获取广告对应的曝光量 不分页
	 * @param companyId
	 * @param adOrderId
	 * @param adStyleId
	 * @param adId
	 * @param beforeDay
	 * @return
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	List<DisplayCountDTO> selectAdAndCount(
			@Param("companyId") String companyId,
			@Param("adOrderId") String adOrderId,
			@Param("adStyleId") String adStyleId, @Param("adId") String adId,
			@Param("beforeDay") String beforeDay);

	/**
	 * 
	 * @Title: selectAdAndCountPage  
	 * @Description: 获取广告对应的曝光量 分页 
	 * @param pagination
	 * @param companyId
	 * @param adOrderId
	 * @param adStyleId
	 * @param adId
	 * @param beforeDay
	 * @return
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	List<DisplayCountDTO> selectAdAndCountPage(Pagination pagination,
			@Param("companyId") String companyId,
			@Param("adOrderId") String adOrderId,
			@Param("adStyleId") String adStyleId, @Param("adId") String adId,
			@Param("beforeDay") String beforeDay);

	/**
	 * 
	 * @Title: selectCountPlatPage  
	 * @Description: 查询公司在平台的统计数量 分页
	 * @param pagination
	 * @param companyId
	 * @param adOrderId
	 * @param adStyleId
	 * @param adId
	 * @param beforeDay
	 * @return
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	List<DisplayCountDTO> selectCountPlatPage(Pagination pagination,
			@Param("companyId") String companyId,
			@Param("adOrderId") String adOrderId,
			@Param("adStyleId") String adStyleId, @Param("adId") String adId,
			@Param("beforeDay") String beforeDay);

/**
 * 
 * @Title: selectCountForPlat  
 * @Description: 查询公司在平台的统计数量 导出excel
 * @param companyId
 * @param adOrderId
 * @param adStyleId
 * @param adId
 * @param beforeDay
 * @return
 * @author guofei 
 * @date 2017年5月5日
 */
	List<DisplayCountDTO> selectCountForPlat(@Param("companyId") String companyId,@Param("adOrderId")String adOrderId,
			@Param("adStyleId") String adStyleId, @Param("adId") String adId,
			@Param("beforeDay") String beforeDay);

	/**
	 * 
	 * @Title: selectDisplayCount  
	 * @Description: 统计前一天的曝光量和用户量 
	 * @param beforeDay
	 * @param nowDay
	 * @return
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	List<AdDisplayCount> selectDisplayCount(
			@Param("beforeDay") String beforeDay, @Param("nowDay") String nowDay);

	/**
	 * 
	 * @Title: selectCountForLine  
	 * @Description:生成统计折线图 
	 * @param companyId
	 * @param adOrderId
	 * @param adStyleId
	 * @param adId
	 * @param beforeDay
	 * @return
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	List<DisplayCountDTO> selectCountForLine(
			@Param("companyId") String companyId,
			@Param("adOrderId") String adOrderId,
			@Param("adStyleId") String adStyleId, @Param("adId") String adId,
			@Param("beforeDay") String beforeDay);

	/**
	 * @param companyId
	 * @param adId
	 * @param adStyleId
	 * @param tortTimeStart
	 * @param tortTimeEnd
	 * @return List<AdDisplayCount>
	 * @throws
	 *
	 * @title getAdCountList4Chart
	 * @description TODO 获取广告相关曝光信息（按日期统计）
	 * @author mxy
	 * @date 2017-04-19 16:43
	 * @modifier
	 * @remark
	 * @version V1.0
	 */
	List<AdDisplayCount> getAdCountList4Chart(@Param("companyId") Long companyId, @Param("adId") Long adId, @Param("adStyleId") Long
			adStyleId, @Param("tortTimeStart") Date tortTimeStart, @Param("tortTimeEnd") Date tortTimeEnd);
	/**
	 * 
	 * 
	 * @Title: selectCountForPlatChart  
	 * @Description: 获取平台统计图    
	 * @param companyId
	 * @param adOrderId
	 * @param adStyleId
	 * @param adId
	 * @param beforeDay
	 * @return
	 * @author guofei 
	 * @date 2017年5月5日
	 */
	List<DisplayCountDTO> selectCountForPlatChart(@Param("companyId")String companyId, @Param("adOrderId")String adOrderId,@Param("adStyleId") String adStyleId, @Param("adId")String adId,
			@Param("beforeDay")String beforeDay);
}
