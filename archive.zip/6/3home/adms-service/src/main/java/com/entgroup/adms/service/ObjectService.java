package com.entgroup.adms.service;

import com.entgroup.adms.model.system.RecognitionObject;
import com.baomidou.mybatisplus.service.IService;

/**
 * <p>
 * 物品表 服务类
 * </p>
 *
 * @author hpb
 * @since 2017-03-08
 */
public interface ObjectService extends IService<RecognitionObject> {
	
}
