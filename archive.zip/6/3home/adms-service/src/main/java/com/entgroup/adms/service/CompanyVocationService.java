package com.entgroup.adms.service;

import com.baomidou.mybatisplus.service.IService;
import com.entgroup.adms.model.system.CompanyVocation;

/**
 * <p>
 * 企业表 服务类
 * </p>
 *
 * @author cuixiaokun
 * @since 2017-03-23
 */
public interface CompanyVocationService extends IService<CompanyVocation> {
}
