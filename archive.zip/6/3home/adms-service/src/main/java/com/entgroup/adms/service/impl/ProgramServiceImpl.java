package com.entgroup.adms.service.impl;

import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.entgroup.adms.mapper.ProgramMapper;
import com.entgroup.adms.model.system.Program;
import com.entgroup.adms.service.ProgramService;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 节目表 服务实现类
 * </p>
 *
 * @author hpb
 * @since 2017-03-08
 */
@Service
public class ProgramServiceImpl extends ServiceImpl<ProgramMapper, Program> implements ProgramService {

	/**
	 * @param page
	 * @param name
	 * @param companyId
	 * @param typeId
	 * @param levelId
	 *
	 * @return Page<Program>
	 *
	 * @throws ???
	 * @title getProgramPriceList
	 * @description TODO 获取节目价格信息列表
	 * @author mxy
	 * @date 2017-03-21 10:29
	 * @modifier
	 * @remark
	 * @version V1.0
	 */
	@Override
	public Page<Program> getProgramPriceList(Page<Program> page, String name, Long companyId, Long typeId,
			Integer levelId) {
		page.setRecords(baseMapper.getProgramPriceList(page.getOrderByField() + (page.isAsc() ? " ASC" : " DESC"),
													   (page.getCurrent() - 1)*page.getSize(), page.getSize(), name, companyId,
													   typeId, levelId));
		return page;
	}
}
